import acsse.csc2a.gui.SpacePane;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;
public class Main extends Application {
	private static final int Height= 600;
	private static final int width= 1024;

	@Override
	public void start(Stage primaryStage) throws Exception {
		 
		SpacePane root = new SpacePane();
		Scene scene= new Scene(root,width,Height);
		primaryStage.setScene(scene);
		root.Background();
		primaryStage.setTitle("Space Riders");
		primaryStage.show();
	}

	/**
	 * @param args start the application
	 */
	public static void main(String[] args) {
		launch(args);
	}

}
