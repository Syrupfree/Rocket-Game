package acsse.csc2a.File;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import acsse.csc2a.model.objects.Asteroid;
import acsse.csc2a.model.objects.MovingObject;
import acsse.csc2a.model.objects.ShadowShip;
import acsse.csc2a.model.objects.ShipType;
import acsse.csc2a.model.objects.SpaceShip;

/**
 * File designated for file handling
 * @author LRB Motaung
 *
 */
public class FileHandling {
	private static ArrayList<MovingObject> Objects =null;
	//Pattern that matches each object type
	final static Pattern SpaceShipPattern = Pattern.compile("[0-9]{1,4}\\t[0-9]{1,4}\\t(SOLID)");
	final static Pattern SShipPattern = Pattern.compile("[0-9]{1,4}\\t[0-9]{1,4}\\t(SHADOW)");
	final static Pattern AsteroidPattern = Pattern.compile("[0-9]{1,4}\\t[0-9]{1,4}\\t[0-9]{1,3}");

	/**
	 * read text files and set to objects
	 * @param NF the file that will be read
	 * @return an arrayList of MovingObject
	 */
	public static ArrayList<MovingObject> ReadFile(File NF)
	{
		Objects= new ArrayList<>();
		Scanner readF=null;
		try
			{
			 readF=new Scanner(NF);
			 while(readF.hasNext())
			 {
				 String line= readF.nextLine();
				 Matcher SpShipMatcher= SpaceShipPattern.matcher(line);
				 Matcher Asteroidmatcher= AsteroidPattern.matcher(line);
				 Matcher SshipMatcher=SShipPattern.matcher(line);
				 if(SpShipMatcher.matches())
				 {
					 SpaceShip ship= convoToSpaceShip(line);
					 Objects.add(ship);
				 }else if(Asteroidmatcher.matches())
				 { 
					 Asteroid A= convoToAsteroid(line);
				 		Objects.add(A);
					 
				 }else if(SshipMatcher.matches())
				 {
					 ShadowShip B= convoToShadowShip(line);
				 		Objects.add(B);
					 
				 }
				 else
				 {
					 System.out.print("File Does not Exit ");
				 }
			 }
			
			}catch(FileNotFoundException e) {e.printStackTrace();}
		
		return Objects;
	}
	
	/**
	 * @param line String that has to be broken up and set to object elements
	 * @return the object 
	 */
	private static SpaceShip convoToSpaceShip(String line)
	{
		StringTokenizer tokenizer = new StringTokenizer(line, "\t");
		double speed = Double.parseDouble(tokenizer.nextToken());
		double radius = Double.parseDouble(tokenizer.nextToken());
		ShipType t=ShipType.valueOf(tokenizer.nextToken());
		return new SpaceShip(speed,radius,t);
	}
	/**
	 * @param line String that has to be broken up and set to object elements
	 * @return the object 
	 */
	private static ShadowShip convoToShadowShip(String line)
	{
		StringTokenizer tokenizer = new StringTokenizer(line, "\t");
		
		double speed = Double.parseDouble(tokenizer.nextToken());
		double radius = Double.parseDouble(tokenizer.nextToken());
		ShipType t=ShipType.valueOf(tokenizer.nextToken());
		return new ShadowShip(speed,radius,t);
	}
	/**
	 * @param line String that has to be broken up and set to object elements
	 * @return the object 
	 */
	private static Asteroid convoToAsteroid(String line)
	{
		StringTokenizer tokenizer = new StringTokenizer(line, "\t");
		
		double speed = Double.parseDouble(tokenizer.nextToken());
		double radius = Double.parseDouble(tokenizer.nextToken());
		int num= Integer.parseInt(tokenizer.nextToken());
		return new Asteroid(speed,radius,num);
	}
}
