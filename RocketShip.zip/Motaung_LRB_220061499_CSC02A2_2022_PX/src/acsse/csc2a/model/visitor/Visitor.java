package acsse.csc2a.model.visitor;

import acsse.csc2a.model.objects.Asteroid;
import acsse.csc2a.model.objects.ShadowShip;
import acsse.csc2a.model.objects.SpaceShip;

/**
 *class to be implemented by Graphics
 * @author LRB Motaung
 * @version PX
 */
public interface Visitor {
 
	/**
	 * @param Ship instance of a SpaceShip
	 */
	public void visit (SpaceShip Ship);
	/**
	 * @param Ship instance of a ShadowShip
	 */
	public void visit (ShadowShip Ship);
	/**
	 * @param As instance of an Asteroid
	 */
	public void visit (Asteroid As);
 
}
