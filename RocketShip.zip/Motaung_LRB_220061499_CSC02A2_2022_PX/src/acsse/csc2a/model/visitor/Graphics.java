package acsse.csc2a.model.visitor;

import acsse.csc2a.model.objects.Asteroid;
import acsse.csc2a.model.objects.ShadowShip;
import acsse.csc2a.model.objects.SpaceShip;
import javafx.scene.image.ImageView;

/**
 *class to implement the visitor class by creating movable objects
 * @author LRB Motaung
 * @version PX
 *
 */
public class Graphics implements Visitor {
	
	private ImageView spaceship;
	private ImageView AST;
	private ImageView ShadowShip;
		/**
		 * Constructor for Graphics to call the visitors and create objects with images to be placed on the scene
		 * @param ship instance of SpaceShip
		 * @param Sship instance of ShadowShip
		 * @param AS instance of Asteroid
		 */
		public Graphics(SpaceShip ship, ShadowShip Sship,Asteroid AS)
	{
		visit(ship);
		visit(Sship);
		visit(AS);
		
	}
	@Override
	public void visit(SpaceShip Ship) {
		spaceship= new ImageView(Ship.getImageURL());
		spaceship.setLayoutX(20);
		spaceship.setLayoutY(130);
	}

	@Override
	public void visit(ShadowShip Ship) {
		
		ShadowShip=new ImageView(Ship.getImageURL());
		ShadowShip.setLayoutX(1000);
		ShadowShip.setLayoutY(55);;
		
	}

	@Override
	public void visit(Asteroid As) {
		
			 AST= new ImageView(As.getImageURL());
	}
	/**
	 * @return the image of space ship
	 */
	public ImageView getSpaceShip()
	{
		return spaceship;
	}
	/**
	 * @return the image of shadow ship
	 */
	public ImageView getShadowship()
	{
		return ShadowShip;
	}
	/**
	 * @return the image of ONE asteroid
	 */
	public ImageView getAsteroid()
	{
		return  AST;
	}
	

}
