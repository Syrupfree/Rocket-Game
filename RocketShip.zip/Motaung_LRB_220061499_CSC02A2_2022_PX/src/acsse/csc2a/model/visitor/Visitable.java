package acsse.csc2a.model.visitor;

/**
 *class to be called by objects that can be visited
 * @author LRB Motaung
 * @version PX
 */public interface Visitable {
	/**
	 * @param Ivisitor to be implement by objects
	 */
	public void accept(Visitor Ivisitor);

}
