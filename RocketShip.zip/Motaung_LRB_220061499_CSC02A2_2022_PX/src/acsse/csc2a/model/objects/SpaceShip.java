package acsse.csc2a.model.objects;

import acsse.csc2a.model.visitor.Visitor;
/**
 *A SpaceShip class
 * @author LRB Motaung
 * @version PX
 *
 */
public class SpaceShip extends MovingObject {

	private final static String ImageURLset="/Images/spaceShips_008.png";
	private ShipType type;
	
	/**
	 * Constructor For SpaceShip
	 * @param Speed initialize speed
	 * @param rad initialize radius
	 * @param type initialize type
	 */
	public SpaceShip(double Speed,double rad,ShipType type) {
		super(Speed,rad);	
		this.type=type;
		
	}
	/**
	 * Getter for type of ship
	 * @return the type
	 */
	public ShipType getType()
	{
		return type;
	}

	/**
	 * Getter for Image URL
	 * @return the image URL
	 */
	public String getImageURL()
	{
		return ImageURLset;
	}
				
	
	@Override
	public void accept(Visitor Ivisitor) {
		Ivisitor.visit(this);
		
	}

	

}
