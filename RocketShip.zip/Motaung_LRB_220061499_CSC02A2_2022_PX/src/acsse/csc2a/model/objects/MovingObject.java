package acsse.csc2a.model.objects;

import acsse.csc2a.model.visitor.Visitable;
import acsse.csc2a.model.visitor.Visitor;
import javafx.scene.image.ImageView;

/**
 * An abstract class of moving objects
 * @author LRB Motaung
 * @version PX
 */
public abstract class MovingObject implements Visitable {
	

/**
 * radius of object
 */
protected double ObjectRadius;
/**
 * speed of object
 */
protected double Speed;
/**
 * Image to be used as a moving object
 */
protected ImageView ObjectImage;

/**
 * Constructor For ShadowShip
 * @param Speed initialize speed
 * @param objectRadius initialize radius
 */
public MovingObject(double Speed,double objectRadius)
{
	
	this.Speed=Speed;
	this.ObjectRadius=objectRadius;

}

/**
 * Getter for radius
 * @return the radius
 */
public double getobjectRadius()
{
	return ObjectRadius;
}
/**
 * Getter for Speed
 * @return the speed
 */
public double getSpeed()
{
	return Speed;
}

@Override
public void accept(Visitor Ivisitor) {
}

}
