package acsse.csc2a.model.objects;

import acsse.csc2a.model.visitor.Visitor;
/**
 * An abstract class of moving objects
 * @author LRB Motaung
 * @version PX
 */
public class Asteroid extends MovingObject  {
	private final static String ImageURLset="/Images/Asteroid.png";
	private int numAsteroids;

	/**
	 * Constructor For Asteroid Class
	 * @param Speed initialize speed
	 * @param rad initialize radius
	 * @param numAsteroids initialize number of asteroids
	 */
	public Asteroid(double Speed,double rad,int numAsteroids) {
		super( Speed,rad);
		this.numAsteroids=numAsteroids;
	}
	
	/**
	 * Getter for num Asteroids
	 * @return  the numAsteroids
	 */
	public int getNumasteroids()
	{
		return numAsteroids;
	}
	/**
	 * Getter for image URL
	 * @return  the URL
	 */
	public String getImageURL()
	{
		return ImageURLset;
	}

	@Override
	public void accept(Visitor Ivisitor) {
		Ivisitor.visit(this);
		
	}
	
	
}
