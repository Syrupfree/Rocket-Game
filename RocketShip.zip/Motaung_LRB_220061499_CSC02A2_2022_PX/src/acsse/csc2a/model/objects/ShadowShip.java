package acsse.csc2a.model.objects;

import acsse.csc2a.model.visitor.Visitor;
/**
 * A ShadowShip/Rescue ship class
 * @author LRB Motaung
 * @version PX
 *
 */
public class ShadowShip extends MovingObject  {
	private final static String ImageURLset="/Images/spaceBuilding_010.png";
	private ShipType type;//to Distinguish between fleeing ship and rescue ship

	/**
	 * Constructor For ShadowShip
	 * @param Speed initialize speed
	 * @param rad initialize radius
	 * @param type initialize type
	 */
	public ShadowShip( double Speed,double rad,ShipType type) {
		super(Speed,rad);
				this.type=type;
	}

	@Override
	public void accept(Visitor Ivisitor) {
		Ivisitor.visit(this);
		
	}
	/**
	 * Getter for image URL
	 * @return  the URL
	 */
	public String getImageURL()
	{
		return ImageURLset;
	}
	
	/**
	 * getter for the type
	 * @return the type
	 */
	public ShipType getType()
	{
		return type;
	}
	
	
	

}
