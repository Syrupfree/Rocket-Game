package acsse.csc2a.model.objects;

/**
 * An enumeration class for ship type
 * @author LRB Motaung
 * @version PX
 */
public enum ShipType {
	
	/**
	 * rescue ship of base
	 */
	SHADOW,
	/**
	 * Space ship
	 */
	SOLID 
}
