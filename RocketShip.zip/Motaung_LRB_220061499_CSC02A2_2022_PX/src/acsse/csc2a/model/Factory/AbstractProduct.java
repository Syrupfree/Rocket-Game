package acsse.csc2a.model.Factory;
/**
 *Abstract Product to be implement in product
 * @author LRB Motaung
 * @version PX
 
 */

public interface AbstractProduct {
	/**
	 * Specialized mouse command to implement in buttons classes
	 */
	public void Function();

}
