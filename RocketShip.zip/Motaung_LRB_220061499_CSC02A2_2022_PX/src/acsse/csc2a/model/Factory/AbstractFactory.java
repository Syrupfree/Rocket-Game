package acsse.csc2a.model.Factory;

import acsse.csc2a.gui.Scenes;

/**
 *Abstract factory to create instances of the abstract product
 * @author LRB Motaung
 * @version PX
 *
 */
public interface AbstractFactory {

	/**
	 * @param Name Name of button
	 * @param pX X-position of button
	 * @param pY Y-position of button
	 * @return the abstract product
	 */
	public AbstractProduct createExit(String Name, double pX, double pY);
	/**
	 * @param Name Name of button
	 * @param pX X-position of button
	 * @param pY Y-position of button
	 * @return the abstract product
	 */
	public AbstractProduct createStart(String Name, double pX, double pY);
	/**
	 * @param Name Name of button
	 * @param pX X-position of button
	 * @param pY Y-position of button
	 * @param s Scene of the main Stage
	 * @return the abstract product
	 */
	public AbstractProduct createHelp(String Name, double pX, double pY,Scenes s);
	
}
