package acsse.csc2a.model.Factory;


import acsse.csc2a.gui.Scenes;
import acsse.csc2a.gui.Buttons.ExitButton;
import acsse.csc2a.gui.Buttons.HelpButton;
import acsse.csc2a.gui.Buttons.StartButton;


/**
 *Concrete Factory to implement AbstractFactory method
 * @author LRB Motaung
 * @version PX
 *
 */
public class ConcreteFactory implements AbstractFactory {

	
	@Override
	public AbstractProduct createExit(String Name, double pX, double pY) {
		// TODO Auto-generated method stub
		return new ExitButton(Name,pX,pY);
	}

	@Override
	public AbstractProduct createStart(String Name, double pX, double pY) {
		// TODO Auto-generated method stub
		return new StartButton(Name,pX,pY);
	}

	@Override
	public AbstractProduct createHelp(String Name, double pX, double pY, Scenes s) {
		// TODO Auto-generated method stub
		return new HelpButton(Name,pX,pY,s);
	}


}
