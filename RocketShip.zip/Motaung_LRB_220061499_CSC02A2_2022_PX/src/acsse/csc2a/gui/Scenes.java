package acsse.csc2a.gui;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

import javafx.animation.TranslateTransition;
import javafx.scene.SubScene;
import javafx.scene.control.TextArea;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.util.Duration;


/**
 *class to Test if key works and key functions
 * @author LRB Motaung
 * @version PX
 */
public class Scenes extends SubScene {
	
	private boolean Displayed;
	private TextArea Textbox;
	//FileNames
	private final String I="Info.ham";
	private final String R="REF.no";
	/**
	 * Initialize the sub scene and set text box;
	 */
	public Scenes() {
		super(new AnchorPane(),400,400);
		
		Image b= new Image("Images/blue_panel.png",400,400,false,true);
		//background for sub scene
		BackgroundImage Back= new BackgroundImage(b,BackgroundRepeat.NO_REPEAT,BackgroundRepeat.NO_REPEAT,BackgroundPosition.DEFAULT,null);
		AnchorPane root1= (AnchorPane) this.getRoot();
		root1.setBackground(new Background(Back));
		//check if sub scene is in view
		Displayed=true;
		//size of sub scene
		setLayoutX(400);
		setLayoutY(-400);
		//text box to display file data
		Textbox=new TextArea();
		Textbox.setLayoutY(25);
		Textbox.setLayoutX(25);
		Textbox.setPrefWidth(350);
		Textbox.setPrefHeight(350);
		setTextBox(I);
		setTextBox(R);
		root1.getChildren().add(Textbox);
		
	}
	
	/**
	 * Moving the scene in frame and out of frame
	 */
	public void MoveSubScene()
	{	//used for the swift motion
		TranslateTransition tr = new TranslateTransition();
		tr.setDuration(Duration.seconds(1));
		tr.setNode(this);
		
		
		if(Displayed)
		{
			
			Displayed=false;
			tr.setToY(450);
		}
		else
		{
			tr.setToY(-200);
			Displayed=true;
		}
		tr.play();
	}
	/**
	 * @param Filename file that will be read
	 */
	public void setTextBox(String Filename)
	{
		
		File cu= new File("data",Filename);
		String Line=" ";
		Scanner scan= null;
		try
		{
			scan= new Scanner(cu);
			while(scan.hasNext())
			{
				 Line= scan.nextLine()+'\n';//More that one file will be read
				 Textbox.appendText(Line);
			}
		}catch(FileNotFoundException r) {r.printStackTrace();}
		
	}

}
