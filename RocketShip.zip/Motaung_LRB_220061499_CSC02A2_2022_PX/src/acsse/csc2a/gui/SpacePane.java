package acsse.csc2a.gui;


import acsse.csc2a.gui.Buttons.ExitButton;
import acsse.csc2a.gui.Buttons.HelpButton;
import acsse.csc2a.gui.Buttons.StartButton;
import acsse.csc2a.model.Factory.AbstractFactory;
import acsse.csc2a.model.Factory.AbstractProduct;
import acsse.csc2a.model.Factory.ConcreteFactory;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.Background;

/**
 * A main pane class to add nodes(buttons, sub scene ,etc)
 * A Client for the Abstract Factory
 * @author LRB Motaung
 * @version PX
 */
public class SpacePane extends StackPane {
	////Starting position of the first button
	private final int Button_X=80;
	private final int Button_Y=100;
	//instance of the sub scene
	private Scenes StartScene = new Scenes();
	
	//Using Abstract Factory to initialize the buttons
	AbstractFactory factory= null;	//The AbStract factory
	AbstractProduct EButton= null;
	AbstractProduct SButton=null;
	AbstractProduct HButton=null;

	/**
	 * Constructor for the Space pane
	 * Initialize Buttons
	 * Initialize Sub Scene
	 * Add nodes to the Pane
	 */
	public SpacePane()
	{	
		AnchorPane root= new AnchorPane();
		///Exit button
		factory= new ConcreteFactory();
		EButton=factory.createExit("Exit",Button_X,Button_Y+200);
		ExitButton E = (ExitButton) EButton;
		Button Exit= E.getButton();
		//Start Button
		SButton=factory.createStart("Start",Button_X,Button_Y);
		StartButton S= (StartButton) SButton;
		Button Start=S.getButton();
		
		///Help Button
		//The Sub Scene is called in the help button
		HButton =factory.createHelp("Help/Credits",Button_X,Button_Y+100,StartScene);
		HelpButton H= (HelpButton) HButton;
		Button Help= H.getButton();
				
		
		//Adding nodes to the Anchor Pane
		root.getChildren().addAll(Start,Help,Exit,StartScene);
		this.getChildren().add(root);
		
	}
	
	
	/**
	 * Setting the Background for the Main Scene
	 */
	public void  Background()
	{
		Image back= new Image("/Images/First.jpg",1024,600,false,true);
		BackgroundImage Background= new BackgroundImage(back,BackgroundRepeat.REPEAT,BackgroundRepeat.REPEAT,BackgroundPosition.DEFAULT,null);
		this.setBackground(new Background(Background));
	}
	
	
}
