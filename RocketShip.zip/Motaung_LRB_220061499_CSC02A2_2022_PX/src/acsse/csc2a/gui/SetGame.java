package acsse.csc2a.gui;

import java.io.File;
import java.util.ArrayList;
import java.util.Random;

import acsse.csc2a.File.FileHandling;
import acsse.csc2a.model.objects.Asteroid;
import acsse.csc2a.model.objects.MovingObject;
import acsse.csc2a.model.objects.SpaceShip;
import acsse.csc2a.model.visitor.Graphics;
import acsse.csc2a.model.objects.ShadowShip;
import javafx.animation.AnimationTimer;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.paint.Color;
import javafx.scene.layout.Background;
import javafx.stage.Stage;
/**
 *class to initialize the game Stage
 * @author LRB Motaung
 * @version PX
 *
 */
public class SetGame {
	Random generator;
	//Element for a new Stage
	private Scene gScene;
	private AnchorPane gPane;
	private Stage GameStage;
	private Stage MainStage;
	private AnimationTimer gameTime;
	private int Lives=3;
	//Graphics class
	Graphics gr;
	///Moving Nodes to be added to the scene
	private ArrayList<ImageView> AstArray;
	private ImageView ShipImage;
	private ImageView ShadowImage;
	//Object to create nodes
	private ArrayList<MovingObject> objects;
	private Asteroid AST;
	private SpaceShip Ship;
	private ShadowShip ShShip;
	//generate position
	Random rand;
	MoveShip Move=new MoveShip();
	//Lives
	private Label lbl;

	

	/**
	 * Constructor for the game Stage
	 * @param stage the main stage
	 */
	public SetGame( Stage stage)
	{	lbl= new Label("Lives Left: " + Lives);
		lbl.setTextFill(Color.WHITE);
		rand= new Random();
		objects=Handling();
		setElementsObjects();
		gr=new Graphics(Ship,ShShip,AST);
		
		
		
		
		
		this.MainStage=stage;
		stage.hide();
		generator= new Random();
		//Initialize the Scene and Pane
		gPane = new AnchorPane();
		
		gScene= new Scene(gPane,1100,600);
		GameStage= new Stage();
		GameStage.setScene(gScene);
		Background();
		setElementImages();
		setLives();
		Move.keyListeners(gScene);
		Loopgame();
		GameStage.setTitle("Get TO THE RESCUE SHIP");
		GameStage.show();
		
	}
	
	/**
	 * File Handling to receive values from File TO object
	 * @return an array of MovingObjects
	 */
	private ArrayList<MovingObject> Handling()
	{
		ArrayList<MovingObject> objects;
		
		String F= "Readings.dot";
		File cu= new File("data",F);
		objects=FileHandling.ReadFile(cu);
		return objects;
	}
	
	/**
	 * check what type of moving object it is then initialize the moving object
	 */
	private void setElementsObjects()
	{
		for(MovingObject o: objects)
		{
			if(o instanceof SpaceShip)
			{
				Ship= (SpaceShip) o;
			}else if( o instanceof Asteroid)
			{
				AST= (Asteroid) o;
				
			}else if (o instanceof ShadowShip)
			{
				ShShip= (ShadowShip) o;
			}
		}
		
	}
	
	/**
	 * Initialise and set the moving images then adding it to the pane
	 */
	private void setElementImages()
	{
		ShipImage=gr.getSpaceShip();
		//rotate the image 90 degrees
		ShipImage.setRotate(90);
		gPane.getChildren().add(ShipImage);
		ShadowImage=gr.getShadowship();
		ShadowImage.setRotate(16);
		gPane.getChildren().add(ShadowImage);
		setAsteroids();
		
	}
	 /**
	 * Setting the number of asteroid 
	 * initializing the array of asteroids
	 * add the images to the pane
	 */
	private void setAsteroids()
	 {
		 AstArray= new ArrayList<>(AST.getNumasteroids());
		 for(int i=0;i<AST.getNumasteroids();i++)
			{	//Set image for each asteroid
				ImageView Asteroids= new ImageView(AST.getImageURL());
				//start position
				objectStartingPosition(Asteroids);
				//add tem to the pane
				gPane.getChildren().add(Asteroids);
				AstArray.add(Asteroids);	
			}
	 }
	
	/**
	 * Generate a new position for an element
	 * @param view
	 *  takes an object that will be moved
	 */
	private void objectStartingPosition(ImageView view)
	{
		
		view.setLayoutX(rand.nextInt(400,1000));
		view.setLayoutY(rand.nextInt(10,550));
	}
	
	/**
	 * Creating a game loop with Animation Timer
	 */
	private void Loopgame()
	{
		gameTime = new AnimationTimer() {

			@Override
			public void handle(long now) {
				moveElements();
				checkposition();
				checkcollision();
				Move.MovetheShip(ShipImage, Ship);
				
			}
		};
		gameTime.start();
	}



	/**
	 * check when ship hits an asteroid or ship reaches the rescue station
	 */
	private void checkcollision() {
	if(ShipImage.getBoundsInParent().intersects(ShadowImage.getBoundsInParent()))
		
		{
			//Win game
			lbl.setText("GAME WON!!");
			gameTime.stop();
			Timer();
				
		}
		
		for(ImageView e: AstArray)
		{
			if(ShipImage.getBoundsInParent().intersects(e.getBoundsInParent()))
			
			{
				//You lose a live when hit an asteroid
				Lives--;
				lbl.setText("Lives Left: " +Lives);
				gameLost();
				ShipImage.setVisible(false);
				//ship relocates back to starting position
				ShipImage.setLayoutX(20);
				ShipImage.setLayoutY(130);
				ShipImage.setVisible(true);	
			}
		
	}
		
	}



	/**
	 * Check if the asteroids are behind the ship
	 */
	private void checkposition() {
		for(ImageView e: AstArray)
		{
			if(e.getLayoutX()<10)
				objectStartingPosition(e);
		}
		
	}



	/**
	 * Moving the asteroids from right to left
	 */
	private void moveElements() {
		for(ImageView e: AstArray)
		{
			e.setLayoutX(e.getLayoutX()-AST.getSpeed());
		}
		
	}
	
	/**
	 * Set condition when game is lost
	 * close the game stage
	 * open Main Stage
	 */
	private void gameLost()
	{
		if(Lives==0)
		{	lbl.setText("GameLost!!");
			gameTime.stop();
			Timer();
		}
	}
	/**
	 * Setting the position of the life label;
	 * Adding label to the current pane
	 */
	private void setLives()
	{
		lbl.setLayoutX(500);
		lbl.setLayoutY(20);
		gPane.getChildren().add(lbl);
	}
	
	/**
	 * Setting the back ground of the game scene
	 */
	public void  Background()
	{
		Image back= new Image("/Images/Second.jpg",1100,600,false,true);
		BackgroundImage Background= new BackgroundImage(back,BackgroundRepeat.REPEAT,BackgroundRepeat.REPEAT,BackgroundPosition.DEFAULT,null);
		gPane.setBackground(new Background(Background));
	}
	
	/**
	 * create a delay between closing and opening of scenes
	 */
	private void Timer()
	{	//current time
		 long CurrentTime = System.currentTimeMillis();
		//end in 3 seconds
		long TimeEnd=CurrentTime+ 3000;
		//stop the game
		while(TimeEnd>CurrentTime)
		{	CurrentTime=System.currentTimeMillis();
		}//close after 3 seconds
			GameStage.close();
			MainStage.show();
			
	
	}
	
}
