package acsse.csc2a.gui;

import acsse.csc2a.model.objects.SpaceShip;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;

/**
 *class to Test if key works and key functions
 * @author LRB Motaung
 * @version PX
 */
public class MoveShip {
	private boolean downkeypressed;
	private boolean rightkeypressed;
	private boolean upkeypressed;
	
	/**
	 * listen to keys being pressed and released
	 * @param gScene that the scene that will be moves
	 */
	public void keyListeners(Scene gScene)
	{
		gScene.setOnKeyPressed(new EventHandler <KeyEvent>()
				{

					@Override
					public void handle(KeyEvent event) {
						if(event.getCode()==KeyCode.UP)
						{
							upkeypressed=true;
						}else if (event.getCode()== KeyCode.RIGHT)
						{
							rightkeypressed=true;
						}else if(event.getCode()== KeyCode.DOWN)
						{
							downkeypressed=true;
						}
						
					}
			
				});
		
		gScene.setOnKeyReleased(new EventHandler <KeyEvent>()//key is released
		{

			@Override
			public void handle(KeyEvent event) {
				if(event.getCode()==KeyCode.UP)
				{
					upkeypressed=false;
				}else if (event.getCode()== KeyCode.DOWN)
				{
					downkeypressed=false;
				}else if (event.getCode()== KeyCode.RIGHT)
				{
					rightkeypressed=false;}
				
				
			
	
			}});
	}
	/**
	 * Move ship according to which button/buttons are pressed
	 * @param Ship that will be moved
	 * @param S object with required values
	 */
	public void MovetheShip(ImageView Ship,SpaceShip S)
	{
		
			
			if(upkeypressed && !downkeypressed  && !rightkeypressed)//just the up key
			{	
				Ship.setLayoutY(Ship.getLayoutY()-S.getSpeed());
				
			}else if (upkeypressed && !downkeypressed  && rightkeypressed)//up and right key
			{
				Ship.setLayoutY(Ship.getLayoutY()-S.getSpeed());
				Ship.setLayoutX(Ship.getLayoutX()+S.getSpeed());
			}
			else if (!upkeypressed && downkeypressed  && !rightkeypressed)//just the down key
			{	Ship.setLayoutY(Ship.getLayoutY()+S.getSpeed());
				
			}
			else if (!upkeypressed && downkeypressed  && rightkeypressed)//down and right
			{
				Ship.setLayoutY(Ship.getLayoutY()+S.getSpeed());
				Ship.setLayoutX(Ship.getLayoutX()+S.getSpeed());
				
			}
		else if (!upkeypressed && !downkeypressed  && rightkeypressed)//just the right key
			{
				Ship.setLayoutX(Ship.getLayoutX()+S.getSpeed());
			}
		
		
		
	}
}
