package acsse.csc2a.gui.Buttons;

import acsse.csc2a.model.Factory.AbstractProduct;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;

/**
 * A class for the exit button
 * @author LRB Motaung
 * @version PX
 */
public class ExitButton extends Buttons implements AbstractProduct {

	/**
	 * Constructor for Exit button
	 * @param Name Name of the button
	 * @param pX X-position of the button
	 * @param pY Y-Position of the button
	 */
	public ExitButton(String Name, double pX, double pY) {
		super(Name, pX, pY);
		Function();
	}
	
	@Override
	public void Function()
	{
		Bt.setOnAction(new EventHandler<ActionEvent> ()
		{

			@Override
			public void handle(ActionEvent event) {
				
				Platform.exit();//close the application
			}
	
		});
	}

}
