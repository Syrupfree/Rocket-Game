package acsse.csc2a.gui.Buttons;

import acsse.csc2a.gui.Scenes;
import acsse.csc2a.model.Factory.AbstractProduct;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;

/**
 * A Class for the help button
 * @author LRB Motaung
 * @version PX
 */
public class HelpButton extends Buttons implements AbstractProduct {
		
	Scenes Sub;
	/**
	 * Constructor for Exit button
	 * @param Name Name of the button
	 * @param pX X-position of the button
	 * @param pY Y-Position of the button
	 * @param s Sub scene to be requested
	 */
	public HelpButton(String Name, double pX, double pY,Scenes s) {
		super(Name, pX, pY);
		Sub=s;	
		Function();
	}
	
	@Override
	public void Function()
	{
		Bt.setOnAction(new EventHandler<ActionEvent> ()
		{

			@Override
			public void handle(ActionEvent event) {
				
				Sub.MoveSubScene();//Move the sub scene into frame when button is pressed
			}
	
		});
	}


}
