package acsse.csc2a.gui.Buttons;

import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.MouseButton;
import javafx.scene.text.Font;

/**
 * An abstract class to create a generic button
 * @author LRB Motaung
 * @version PX
 */
public class Buttons  {
	//Setting Style for image background
	private final String Button_pressed="-fx-background-color: transparent;";
	private final String button_default="-fx-backgroundcolor:white;";
	//button instance
	Button Bt;
	/**
	 * Constructor for Buttons Class
	 * @param Name Name of the button
	 * @param pX X-position of the button
	 * @param pY Y-Position of the button
	 */
	public Buttons(String Name,double pX,double pY)
	
	{	Bt= new Button();
		//setting the button name with font
		Bt.setText(Name);
		Bt.setFont(Font.font("Times New Roman", 15));
		//setting a button to an image
		Bt.setStyle(button_default);
		Bt.setPrefHeight(49);
		Bt.setPrefWidth(190);
		BTListener();
		//setting the position of the button
		Bt.setLayoutX(pX);
		Bt.setLayoutY(pY);
		
	}
	
	/**
	 * Creating generic mouse commands 
	 */
	private void BTListener()
	{
		Bt.setOnMousePressed(new EventHandler<MouseEvent>() {

			@Override
			public void handle(MouseEvent event) {
				Bt.setStyle(Button_pressed);;
				//visual representation to see when a button is clicked
				Bt.setPrefHeight(45);
				Bt.setLayoutY(Bt.getLayoutY());			
			}
			
			
		});
		Bt.setOnMouseReleased(new EventHandler<MouseEvent>()
				{

					@Override
					public void handle(MouseEvent event) {
						if(event.getButton().equals(MouseButton.PRIMARY)) {
							Bt.setStyle(button_default);
							Bt.setPrefHeight(Bt.getHeight());
							Bt.setLayoutY(Bt.getLayoutY());
						}
						
					}
			
				});
	}
	
	
	/**
	 * getter for button instance
	 * @return the button instance
	 */
	public Button getButton()
	{
		return Bt;
	}
	
	

}
