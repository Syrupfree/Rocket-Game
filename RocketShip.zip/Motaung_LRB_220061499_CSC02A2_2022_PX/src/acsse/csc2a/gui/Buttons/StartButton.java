package acsse.csc2a.gui.Buttons;

import acsse.csc2a.gui.SetGame;
import acsse.csc2a.model.Factory.AbstractProduct;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.stage.Stage;

/**
 * A Class for the help button
 * @author LRB Motaung
 * @version PX
 */
public class StartButton extends Buttons implements AbstractProduct {
	
	Stage stage;
	SetGame startgame;
	/**
	 * Constructor for Exit button
	 * @param Name Name of the button
	 * @param pX X-position of the button
	 * @param pY Y-Position of the button
	 */
	public StartButton(String Name, double pX, double pY) {
		super(Name, pX, pY);
			Function();
	}
		
	
	@Override
	public void Function() {
		Bt.setOnAction(new EventHandler<ActionEvent> ()
				{

					@Override
					public void handle(ActionEvent event) {
						//getting an instance of a stage to be able to close the stage
						Node node= (Node) event.getSource();
						//opening the game stage
						stage= (Stage) node.getScene().getWindow();
						stage.hide();
						startgame= new SetGame(stage);
					 
					}
			
				});
			
		
	}
}
